
todayDayName=$(date +%a)

tomorrowDate=$(date --date='tomorrow' +%d)

echo $todayDayName
echo $tomorrowDate
echo "**********"

if [[ $todayDayName == "Fri" || $tomorrowDate == "01" ]]
then

echo $todayDayName
echo $tomorrowDate
##Take the latest from SVN 
cd /home/weblogic/REPORTS/SVN/DEV/
svn co "https://57.6.248.31/svn/voyager/Documentation/TechnicalArchitecture/trunk/Integration/Tracking/"
cd  /home/weblogic/REPORTS/SVN/DEV/Tracking/
chmod 775 * 

cd /home/weblogic/REPORTS/SVN/PROD/
svn co "https://57.6.248.31/svn/voyager/Documentation/TechnicalArchitecture/trunk/PRODUCTION TEAM/Tracking/"
cd /home/weblogic/REPORTS/SVN/PROD/Tracking/
chmod 775 *

##Execute the daily report
cd /home/weblogic/REPORTS/WeeklyReports
java -jar WeeklyReports.jar

fi
